import React from 'react'

const AllAnalysisboardcomponent = () => {
    return (
        <div>

        </div>
    )
}

export default AllAnalysisboardcomponent
